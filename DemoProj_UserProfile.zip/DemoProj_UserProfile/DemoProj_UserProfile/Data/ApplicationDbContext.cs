﻿using DemoProj_UserProfile.Models;
using Microsoft.EntityFrameworkCore;


namespace DemoProj_UserProfile.Data
{
    public class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext()
        {
        }

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
           : base(options)
        {

        }

        public DbSet<User_Info> User_Info { get; set; }
    }
}
