﻿using DemoProj_UserProfile.Data;
using DemoProj_UserProfile.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Net;

namespace DemoProj_UserProfile.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserAdminController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public UserAdminController(ApplicationDbContext context)
        {
            _context = context;
        }


        //Using Entity Framework to fetch records from DB
        [HttpGet("GetAllUsers_UsingEntityFramework")]
        public async Task<ActionResult<List<User_Info>>> GetAllUsers()
        {
            try
            {
                var List = await _context.User_Info.Select(
                    s => new User_Info
                    {
                        FirstName = s.FirstName,
                        LastName = s.LastName,
                        PhoneNumber = s.PhoneNumber,
                        Address = s.Address,
                        EmailAddress = s.EmailAddress
                    }
                ).ToListAsync();

                if (List.Count < 0)
                {
                    return NotFound();
                }
                else
                {
                    return List;
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //With Out Entity Framework , using store proc to fetch the records
        [HttpGet]
        [Route("GetAllUser_UsingStoredProc")]
        public async Task<ActionResult<IEnumerable<User_Info>>> GetAllUser()
        {
            try
            {
                string StoredProc = "exec usp_GetUserInfo";

                return await _context.User_Info.FromSqlRaw(StoredProc).ToListAsync();
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //Update the user
        [HttpPut("UpdateUser")]
        public async Task<HttpStatusCode> UpdateUser(User_Info User)
        {
            try
            {
                var entity = await _context.User_Info.FirstOrDefaultAsync(s => s.ID == User.ID);
                entity.FirstName = User.FirstName;
                entity.LastName = User.LastName;
                entity.PhoneNumber = User.PhoneNumber;
                entity.Address = User.Address;
                entity.EmailAddress = User.EmailAddress;
                await _context.SaveChangesAsync();
                return HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //Add user in DB
        [HttpPost("InsertUser")]
        public async Task<HttpStatusCode> InsertUser(User_Info User)
        {
            try
            {
                var entity = new User_Info()
                {
                    FirstName = User.FirstName,
                    LastName = User.LastName,
                    PhoneNumber = User.PhoneNumber,
                    Address = User.Address,
                    EmailAddress = User.EmailAddress
                };
                _context.User_Info.Add(entity);
                await _context.SaveChangesAsync();
                return HttpStatusCode.Created;
            }
            catch (Exception ex)
            {
                throw;
            }
        }


        //Delete the user by ID
        [HttpDelete("DeleteUser/{Id}")]
        public async Task<HttpStatusCode> DeleteUser(int Id)
        {
            try
            {
                var entity = new User_Info()
                {
                    ID = Id
                };
                _context.User_Info.Attach(entity);
                _context.User_Info.Remove(entity);
                await _context.SaveChangesAsync();
                return HttpStatusCode.OK;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
